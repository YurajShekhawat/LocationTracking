package com.example.locationtracker

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices


class MainActivity : AppCompatActivity() {
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fusedLocationProviderClient= LocationServices.getFusedLocationProviderClient(this)

        val btnLocation=findViewById<Button>(R.id.button_Location)


        btnLocation.setOnClickListener{
            findLocation()
        }
    }

    @SuppressLint("SetTextI18n")
    private fun findLocation() {
        if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION) != (PackageManager.PERMISSION_GRANTED) &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),100)
            return
        }
        val location = fusedLocationProviderClient.lastLocation

        location.addOnSuccessListener {
            val submitField=findViewById<TextView>(R.id.address_text_view)
            if (it!=null){
                val ltLatitude= it.latitude
                val ltLongitude= it.longitude

                if((ltLatitude in 26.903220..26.903400) && (ltLongitude in 75.781610..75.781840)){
                    submitField.text="Welcome Home"
                }
                else  if((ltLatitude in 26.909720..26.909999) && (ltLongitude in 75.782900..75.783200)){
                    submitField.text="Welcome to Meraaki Kitchen"
                }
                else  if((ltLatitude in 26.901700..26.901900) && (ltLongitude in 75.782000..75.782210)){
                    submitField.text ="Welcome to GA infra"
                }
                else  if((ltLatitude in 26.937140..26.937325) && (ltLongitude in 75.795000..75.795200)){
                    submitField.text="You are near SysQuare"
                }
                else
                    submitField.text="Location Can't be Identified"
            }
        }
    }
}
